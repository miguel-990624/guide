import { get, update } from "./services.js";

export async function setupEditCourseView() {
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get("id");

  const form = document.getElementById("edit-course-form");
  if (!form) return;

  if (!courseId) {
    document.querySelector(".edit-course-container").innerHTML = "<p>ID del curso no especificado.</p>";
    return;
  }

  const course = await get("http://localhost:3000/courses", courseId);
  if (!course) {
    document.querySelector(".edit-course-container").innerHTML = "<p>Curso no encontrado.</p>";
    return;
  }

  // Rellenar los inputs
  document.getElementById("edit-course-id").value = course.id;
  document.getElementById("edit-course-title").value = course.title;
  document.getElementById("edit-course-description").value = course.description;
  document.getElementById("edit-course-start").value = course.startDate;
  document.getElementById("edit-course-duration").value = course.duration;

  // Manejador del formulario
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const updatedCourse = {
      id: course.id,
      title: document.getElementById("edit-course-title").value.trim(),
      description: document.getElementById("edit-course-description").value.trim(),
      startDate: document.getElementById("edit-course-start").value,
      duration: document.getElementById("edit-course-duration").value.trim()
    };

    try {
      const result = await update("http://localhost:3000/courses", courseId, updatedCourse);

      if (result?.id) {
        alert("Curso actualizado correctamente");
        history.pushState(null, null, "/courses");
        window.dispatchEvent(new PopStateEvent("popstate"));
      } else {
        alert("No se pudo actualizar el curso");
      }
    } catch (error) {
      console.error("Error al actualizar el curso:", error);
      alert("Error inesperado al actualizar");
    }
  });
}
