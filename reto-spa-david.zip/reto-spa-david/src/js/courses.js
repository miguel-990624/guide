import { get, deletes } from "./services.js";

export async function setupCourses() {
  const ul = document.getElementById("course-list");
  if (!ul) return;

  ul.innerHTML = "";

  const header = document.createElement("li");
  header.classList.add("course-header");
  header.innerHTML = `
    <span>Título</span>
    <span>Descripción</span>
    <span>Inicio</span>
    <span>Duración</span>
    <span>Acciones</span>
  `;
  ul.appendChild(header);

  const courses = await get("http://localhost:3000/courses");
  const currentUser = JSON.parse(localStorage.getItem("loggedUser"));
  const isAdmin = currentUser?.role === "admin";

  courses.forEach((course) => {
    const li = document.createElement("li");
    li.classList.add("course-row");

    const actionsHtml = isAdmin
      ? `
        <button class="edit-course-btn" data-id="${course.id}">✏️</button>
        <button class="delete-course-btn" data-id="${course.id}">🗑️</button>
      `
      : `<span class="no-actions">Sin permisos</span>`;

    li.innerHTML = `
      <span>${course.title}</span>
      <span>${course.description}</span>
      <span>${course.startDate}</span>
      <span>${course.duration}</span>
      <span class="actions">${actionsHtml}</span>
    `;

    ul.appendChild(li);
  });

  // 🎯 Evento delegado para editar o eliminar
  ul.addEventListener("click", async (e) => {
    const id = e.target.dataset.id;

    if (!isAdmin) {
      alert("No tienes permisos para editar o eliminar cursos.");
      return;
    }

    // 🗑️ Eliminar curso
    if (e.target.classList.contains("delete-course-btn")) {
      const confirmDelete = confirm("¿Estás seguro de eliminar este curso?");
      if (confirmDelete) {
        const success = await deletes("http://localhost:3000/courses", id);
        if (success) {
          alert("Curso eliminado");
          setupCourses(); // recargar la lista
        } else {
          alert("No se pudo eliminar el curso");
        }
      }
    }

    // ✏️ Editar curso → redireccionar con ID
    if (e.target.classList.contains("edit-course-btn")) {
      history.pushState(null, null, `/editcourse?id=${id}`);
      window.dispatchEvent(new PopStateEvent("popstate"));
    }
  });

  // 🚫 Ocultar botón "Agregar nuevo curso" si no es admin
  const addBtn = document.querySelector(".actions-footer a");
  if (addBtn && !isAdmin) {
    addBtn.style.display = "none";
  }
}
