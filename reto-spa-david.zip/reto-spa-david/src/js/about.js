export function setupAbout() {
  console.log("🧠 Sección 'Acerca de la app usuarios' cargada correctamente.");

}
