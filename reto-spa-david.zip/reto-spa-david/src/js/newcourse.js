// src/js/newcourse.js
import { post } from "./services.js";

export function setupNewCourse() {
  const form = document.getElementById("new-course-form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const newCourse = {
      title: document.getElementById("course-title").value.trim(),
      description: document.getElementById("course-description").value.trim(),
      startDate: document.getElementById("course-start").value,
      duration: document.getElementById("course-duration").value.trim()
    };

    const created = await post("http://localhost:3000/courses", newCourse);
    if (created?.id) {
      alert("Curso creado exitosamente");
      history.pushState(null, null, "/courses");
      window.dispatchEvent(new PopStateEvent("popstate"));
    } else {
      alert("Error al crear el curso");
    }
  });
}
