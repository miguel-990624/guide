import { update, get } from "./services.js";

export async function setupEditUserView() {
  const form = document.getElementById("edit-user-form");
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get("id");

  if (!userId) {
    document.querySelector(".edit-user-container").innerHTML = "<p>ID de usuario no especificado.</p>";
    return;
  }

  const user = await get("http://localhost:3000/users", userId);

  if (!user) {
    document.querySelector(".edit-user-container").innerHTML = "<p>Usuario no encontrado.</p>";
    return;
  }

  // Rellenar valores en formulario con fallback a ""
  document.getElementById("user-id").value = user.id || "";
  document.getElementById("edit-name").value = user.name || "";
  document.getElementById("edit-email").value = user.email || "";
  document.getElementById("edit-phone").value = user.phone || "";
  document.getElementById("edit-enroll").value = user.enrollNumber || "";
  document.getElementById("edit-date").value = user.dateOfAdmission || "";

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formValues = {
      id: Number(userId),
      name: document.getElementById("edit-name").value.trim(),
      email: document.getElementById("edit-email").value.trim(),
      phone: document.getElementById("edit-phone").value.trim(),
      enrollNumber: document.getElementById("edit-enroll").value.trim(),
      dateOfAdmission: document.getElementById("edit-date").value.trim(),
      password: user.password, // mantenerlo igual
      role: user.role
    };

    try {
      const updatedUser = await update("http://localhost:3000/users", userId, formValues);

      if (updatedUser?.id) {
        alert("Usuario actualizado correctamente");

        // ✅ Redirigir a /users
        history.pushState(null, null, "/users");
        window.dispatchEvent(new PopStateEvent("popstate"));
      } else {
        alert("No se pudo actualizar el usuario");
      }
    } catch (error) {
      console.error("Error al actualizar:", error);
      alert("Error inesperado al actualizar el usuario");
    }
  });
}
