const routes = {
  "/": "src/html/login.html",
  "/users": "src/html/users.html",
  "/newuser": "src/html/newuser.html",
  "/courses": "src/html/courses.html",
  "/newcourse": "src/html/newcourse.html",
  "/editcourse": "src/html/editcourse.html",
  "/about": "src/html/about.html",
  "/edit": "src/html/edit.html"
};

document.body.addEventListener("click", (e) => {
  if (e.target.matches("[data-link]")) {
    e.preventDefault();
    navigate(e.target.getAttribute("href"));
  }
});

export async function navigate(pathname) {
  const user = JSON.parse(localStorage.getItem("loggedUser"));

  // 🚫 Redirección si ya está logueado
  if (pathname === "/" && user) {
    return navigate("/users");
  }

  // 🔒 Bloquear acceso a rutas protegidas
  if (!user && pathname !== "/") {
    alert("Primero iniciá sesión para acceder a esta sección.");
    return navigate("/");
  }

  // 🔒 Solo admins pueden acceder a /newuser
  if (pathname === "/newuser" && user?.role !== "admin") {
    alert("Acceso denegado. No tienes permisos para entrar aquí.");
    return navigate("/users");
  }

  const route = routes[pathname];
  if (!route) return navigate("/");

  try {
    const html = await fetch(route).then((res) => res.text());

    if (pathname === "/") {
      document.getElementById("app").style.display = "none";
      document.getElementById("login-content").innerHTML = html;

      const { setupLogin } = await import("./login.js");
      setupLogin();
    } else {
      document.getElementById("login-content").innerHTML = "";
      document.getElementById("app").style.display = "flex";
      document.getElementById("content").innerHTML = html;

      if (pathname === "/users") {
        const { setupUsers } = await import("./users.js");
        setupUsers();
      }

      if (pathname === "/newuser") {
        const { setupNewUser } = await import("./newuser.js");
        setupNewUser();
      }

      if (pathname === "/about") {
        const { setupAbout } = await import("./about.js");
        setupAbout?.();
      }

      if (pathname === "/edit") {
        const { setupEditUserView } = await import("./edit.js");
        setupEditUserView();
      }

      if (pathname === "/courses") {
        const { setupCourses } = await import("./courses.js");
        setupCourses();
      }

      if (pathname === "/newcourse") {
        const { setupNewCourse } = await import("./newcourse.js");
        setupNewCourse();
      }

      if (pathname === "/editcourse") {
        const { setupEditCourseView } = await import("./editcourse.js");
        setupEditCourseView();
      }

    }

    history.pushState({}, "", pathname);
  } catch (err) {
    console.error("Error navegando:", err);
    alert("Algo salió mal al cargar la vista. Inténtalo de nuevo.");
    if (pathname !== "/") navigate("/");
  }
}

// 🔘 Logout sin Swal
document.addEventListener("click", (e) => {
  if (e.target.id === "logout-btn") {
    const confirmLogout = confirm("¿Cerrar sesión?\nTu sesión actual se cerrará.");
    if (confirmLogout) {
      localStorage.removeItem("loggedUser");
      navigate("/");
    }
  }
});

// ⏪ Navegación del historial
window.addEventListener("popstate", () => navigate(location.pathname));

// 🚀 Carga inicial
navigate(location.pathname);
