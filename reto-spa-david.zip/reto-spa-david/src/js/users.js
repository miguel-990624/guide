import { get, deletes } from "./services.js";

export async function setupUsers() {
  const ul = document.getElementById("user-list");
  if (!ul) return;

  ul.innerHTML = "";

  const header = document.createElement("li");
  header.classList.add("user-header");
  header.innerHTML = `
    <span>Foto</span>
    <span>Nombre</span>
    <span>Email</span>
    <span>Teléfono</span>
    <span>Matrícula</span>
    <span>Ingreso</span>
    <span>Acciones</span>
  `;
  ul.appendChild(header);

  const users = await get("http://localhost:3000/users");
  const currentUser = JSON.parse(localStorage.getItem("loggedUser"));
  const isAdmin = currentUser?.role === "admin";

  users.forEach((user) => {
    const li = document.createElement("li");
    li.classList.add("user-row");

    const actionsHtml = isAdmin
      ? `
        <a href="/edit?id=${user.id}" data-link><button class="edit-btn">✏️</button></a>
        <button class="delete-btn" data-id="${user.id}">🗑️</button>
      `
      : `<span class="no-actions">Sin permisos</span>`;

    li.innerHTML = `
      <span><img src="imgs/csgo.jpeg" alt="foto" class="user-avatar"></span>
      <span>${user.name}</span>
      <span>${user.email}</span>
      <span>${user.phone}</span>
      <span>${user.enrollNumber}</span>
      <span>${user.dateOfAdmission}</span>
      <span class="actions">${actionsHtml}</span>
    `;
    ul.appendChild(li);
  });

  ul.addEventListener("click", async (e) => {
    const id = e.target.dataset.id;
    if (!id) return;

    const currentUser = JSON.parse(localStorage.getItem("loggedUser"));
    if (currentUser?.role !== "admin") {
      alert("No tienes permisos para hacer esta acción.");
      return;
    }

    if (e.target.classList.contains("delete-btn")) {
      const confirmed = confirm("¿Estás seguro de eliminar este usuario?");
      if (confirmed) {
        const success = await deletes("http://localhost:3000/users", id);
        if (success) {
          alert("Usuario eliminado correctamente.");
          setupUsers();
        } else {
          alert("Error al eliminar el usuario.");
        }
      }
    }
  });
}
